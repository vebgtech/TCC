<?php
$servidor = "localhost";      // Nome do servidor (geralmente 'localhost')
$usuario = "root";            // Nome de usuário do banco
$senha = "";                  // Senha do banco
$banco = "vebg";     // Nome do seu banco de dados

// Criar conexão
$conn = new mysqli($servidor, $usuario, $senha, $banco);

// Verificar conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Se tudo deu certo
// echo "Conexão realizada com sucesso!";
?>
