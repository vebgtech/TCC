$("#flip").click(function(){
    $("#panel").slideToggle();
  }); 


